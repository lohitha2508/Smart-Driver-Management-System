const firebaseConfig = {
  apiKey: "AIzaSyBFIVCbFRnXm6bJbSx6BlrM9KGphPIMdFQ",
  authDomain: "skillbridge-4c416.firebaseapp.com",
  projectId: "skillbridge-4c416",
  storageBucket: "skillbridge-4c416.firebasestorage.app",
  messagingSenderId: "135293616070",
  appId: "1:135293616070:web:fb9716ad07b31f9059bcc7",
  measurementId: "G-0JB166R0DY"
};

firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
const db = firebase.firestore();