function register(){

let name=document.getElementById("name").value;

let email=document.getElementById("email").value;

let password=document.getElementById("password").value;

let department=document.getElementById("department").value;

let year=document.getElementById("year").value;

auth.createUserWithEmailAndPassword(email,password)

.then((userCredential)=>{

let uid=userCredential.user.uid;

db.collection("users").doc(uid).set({

name:name,

email:email,

department:department,

year:year

});

alert("Registration Successful");

window.location="login.html";

})

.catch((error)=>{

alert(error.message);

});

}

function login(){

let email=document.getElementById("email").value;

let password=document.getElementById("password").value;

auth.signInWithEmailAndPassword(email,password)

.then(()=>{

alert("Login Successful");

window.location="dashboard.html";

})

.catch((error)=>{

alert(error.message);

});

}