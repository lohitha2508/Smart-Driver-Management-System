function addSkill() {

let user = auth.currentUser;

db.collection("skills").add({

teacherId: user.uid,

skillName: document.getElementById("skillName").value,

description: document.getElementById("description").value,

level: document.getElementById("level").value,

timeSlot: document.getElementById("timeSlot").value,

status: "Available"

})

.then(function(){

alert("Skill Posted Successfully");

document.getElementById("skillName").value="";
document.getElementById("description").value="";
document.getElementById("timeSlot").value="";

})

.catch(function(error){

alert(error.message);

});

}