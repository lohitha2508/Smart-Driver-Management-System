function submitFeedback(){

let rating =
document.getElementById("rating").value;

let comment =
document.getElementById("comment").value;

alert(
"Feedback Submitted\n\nRating : "
+ rating +
"\nComment : " + comment
);

}