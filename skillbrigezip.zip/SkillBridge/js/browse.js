db.collection("skills").get()

.then(function(querySnapshot){

let output = "";

querySnapshot.forEach(function(doc){

let skill = doc.data();

output += `
<div class="card">

<h3>${skill.skillName}</h3>

<p><b>Description:</b> ${skill.description}</p>

<p><b>Level:</b> ${skill.level}</p>

<p><b>Time:</b> ${skill.timeSlot}</p>

<button onclick="requestSkill('${doc.id}')">
Request to Learn</button>

</div>
`;

});

document.getElementById("skillList").innerHTML = output;

});

function requestSkill(skillId) {

let user = auth.currentUser;

db.collection("requests").add({

skillId: skillId,

learnerId: user.uid,

status: "Pending"

})

.then(function(){

alert("Request Sent Successfully");

})

.catch(function(error){

alert(error.message);

});

}