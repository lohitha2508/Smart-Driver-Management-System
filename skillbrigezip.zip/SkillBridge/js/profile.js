auth.onAuthStateChanged(function(user){

if(user){

document.getElementById("email").value = user.email;

db.collection("users").doc(user.uid).get()

.then(function(doc){

if(doc.exists){

let data = doc.data();

document.getElementById("name").value = data.name || "";
document.getElementById("department").value = data.department || "";
document.getElementById("year").value = data.year || "";
document.getElementById("skillsKnown").value = data.skillsKnown || "";
document.getElementById("skillsInterested").value = data.skillsInterested || "";

}

});

}

});

function saveProfile(){

let user = auth.currentUser;

db.collection("users").doc(user.uid).set({

name: document.getElementById("name").value,

email: document.getElementById("email").value,

department: document.getElementById("department").value,

year: document.getElementById("year").value,

skillsKnown: document.getElementById("skillsKnown").value,

skillsInterested: document.getElementById("skillsInterested").value

})

.then(function(){

alert("Profile Saved Successfully");

})

.catch(function(error){

alert(error.message);

});

}