db.collection("requests").get()

.then(function(querySnapshot){

let output="";

querySnapshot.forEach(function(doc){

let req=doc.data();

output+=`
<div class="card">

<p>Status : <b>${req.status}</b></p>

<button onclick="acceptRequest('${doc.id}')">
Accept
</button>

<button onclick="rejectRequest('${doc.id}')">
Reject
</button>

</div>
`;

});

document.getElementById("requestList").innerHTML=output;

});

function acceptRequest(id){

db.collection("requests").doc(id).update({

status:"Accepted"

}).then(function(){

alert("Request Accepted");

location.reload();

});

}

function rejectRequest(id){

db.collection("requests").doc(id).update({

status:"Rejected"

}).then(function(){

alert("Request Rejected");

location.reload();

});

}