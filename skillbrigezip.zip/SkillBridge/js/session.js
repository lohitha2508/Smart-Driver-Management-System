function markScheduled(){

document.getElementById("status").innerHTML =
"Session Status : Scheduled";

}

function markCompleted(){

document.getElementById("status").innerHTML =
"Session Status : Completed";

}